//
//  ViewController.swift
//  LabWork123
//
//  Created by iStudents on 2/6/15.
//  Copyright (c) 2015 iStudents. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    var lab1 = 0
    var lab2 = 0
    var lab3 = 0

    @IBAction func OneB(sender: AnyObject) {
        lab1 = lab1 + 1
        OneLabel.text = String(lab1)
    }
    @IBAction func TwoB(sender: AnyObject) {
        lab2 = lab2 + 1
        TwoLabel.text = String(lab2)

    }
    @IBAction func ThreeB(sender: AnyObject) {
        lab3 = lab3 + 1
       ThreeLabel.text = String(lab3)

    }
    
    @IBOutlet weak var OneLabel: UILabel!
    @IBOutlet weak var TwoLabel: UILabel!
    @IBOutlet weak var ThreeLabel: UILabel!

    
    @IBAction func Reset(sender: AnyObject) {
        OneLabel.text = "0"
        TwoLabel.text = "0"
        ThreeLabel.text = "0"
        
        lab1 = 0
        lab2 = 0
        lab3 = 0
    }
        
    
}

